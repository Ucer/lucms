//拍照
		appendByCamera : function(){
			var that = this;
			plus.camera.getCamera().captureImage(function(file){
		        plus.io.resolveLocalFileSystemURL(file, function(entry) { 
		            var path = entry.toLocalURL() + "?version=" + new Date().getTime();//文件路径
		            var srcPath = entry.toLocalURL();
		            var dstPath = that.savePath + entry.name;
		            var compressOptions = {};
		            
		            entry.file(function(file){
		            	//console.log("文件名称" + file.name + "文件大小" + file.size);
		            });
		            
		            that.callback(file,path,that.options);
		        }, function(e) { 
		            console.log("读取拍照文件错误：" + e.message); 
		        }); 
			});	
		},
		//打开相册
		appendByGallery : function(){
			var that = this;
			plus.gallery.pick(function(file){
		        plus.io.resolveLocalFileSystemURL(file, function(entry) { 
		            var path = entry.toLocalURL() + "?version=" + new Date().getTime();//文件路径
		            var srcPath = entry.toLocalURL();
		            var dstPath = that.savePath + entry.name;
		            var compressOptions = {};
		            
		            entry.file(function(file){
		            	//console.log("文件名称" + file.name + "文件大小" + file.size);
		            });
		            
		            that.callback(file,path,that.options);
		        }, function(e) { 
		            console.log("读取相册文件错误：" + e.message); 
		        }); 
		   	});
		}