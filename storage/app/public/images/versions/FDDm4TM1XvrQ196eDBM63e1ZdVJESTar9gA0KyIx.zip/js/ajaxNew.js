var loginState = false;
var cUrl = 'https://tbdxtapi.gooneplusone.com';
axios.interceptors.request.use(

	function(config) {

			// 判断是否存在token，如果存在的话，则每个http header都加上token
			config.baseURL = 'https://tbdxtapi.gooneplusone.com';
			config.headers.Accept = 'application/json'
			var auth_token = plus.storage.getItem("auth_token");
			//console.log(auth_token);
			if(auth_token){ 
				config.headers.Authorization = "Bearer " + auth_token;
			}
	
		return config;
	},
	function(err) {

		//console.log(1111);
		return Promise.reject(err);
	}
);

// http response 拦截器
axios.interceptors.response.use(
	function(response) {
		
		switch(response.data.code) {
				case -6:
					//setStatusbarMo();
					// 返回 401 清除token信息并跳转到登录页面
					//    Vue.auth.destoryToken();
					
					//plus.nativeUI.toast("离开太久,已掉线,请重新登录！");
					plus.storage.clear();
					//console.log(plus.webview.currentWebview().opener().id);
					
					if(!loginState){
						plus.storage.setItem("status",'1');
						loginState=true;
						viewTo("./login.html");
					}else{
						
					}
					
					break;
				case 404:
					plus.nativeUI.toast("数据不存在！");
					break;
				case 401:
					plus.nativeUI.toast("401！");
					break;
				case 1:
				//loginState=false;
				break;
			}
		return response;
	},
	function(error) {

		console.log(error);
		if(error.response) {
			console.log("sss"+error.response.status);
			switch(error.response.status) {
			
			}
			return Promise.reject(error.response) // 返回接口返回的错误信息
		}

	}
);