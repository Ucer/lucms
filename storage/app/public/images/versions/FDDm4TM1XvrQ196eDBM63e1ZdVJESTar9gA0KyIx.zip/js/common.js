function pageTo(url, data) { //list点击item后的事件
	//bodyLoading();

	webviewContent = plus.webview.create(url, 'id', {scrollIndicator:'none',scalable:false,popGesture:'none'},data); //后台创建webview并打开show.html

	//webviewContent.addEventListener("loaded", function() { //注册新webview的载入完成事件	

		webviewContent.show("slide-in-right", 200); //把新webview窗体显示出来，显示动画效果为速度200毫秒的右侧移入动画

		//把新webview窗体显示出来，显示动画效果为速度200毫秒的右侧移入动画
	//}, false);
}

function pageshow(url, data) { //list点击item后的事件
	//bodyLoading();

	webviewContent = plus.webview.create(url, 'id', {scrollIndicator:'none',scalable:false,popGesture:'none'},data); //后台创建webview并打开show.html

	webviewContent.addEventListener("loaded", function() { //注册新webview的载入完成事件	

		webviewContent.show(); //把新webview窗体显示出来，显示动画效果为速度200毫秒的右侧移入动画

		//把新webview窗体显示出来，显示动画效果为速度200毫秒的右侧移入动画
	}, false);
}


function addClass(obj, cls) {
	var obj_class = obj.className, //获取 class 内容.
		blank = (obj_class != '') ? ' ' : ''; //判断获取到的 class 是否为空, 如果不为空在前面加个'空格'.
	added = obj_class + blank + cls; //组合原来的 class 和需要添加的 class.
	obj.className = added; //替换原来的 class.
};

function removeClass(obj, cls) {
	var obj_class = ' ' + obj.className + ' '; //获取 class 内容, 并在首尾各加一个空格. ex) 'abc    bcd' -> ' abc    bcd '
	obj_class = obj_class.replace(/(\s+)/gi, ' '), //将多余的空字符替换成一个空格. ex) ' abc    bcd ' -> ' abc bcd '
		removed = obj_class.replace(' ' + cls + ' ', ' '); //在原来的 class 替换掉首尾加了空格的 class. ex) ' abc bcd ' -> 'bcd '
	removed = removed.replace(/(^\s+)|(\s+$)/g, ''); //去掉首尾空格. ex) 'bcd ' -> 'bcd'
	obj.className = removed; //替换原来的 class.
};

function hasClass(obj, cls) {
	var obj_class = obj.className, //获取 class 内容.
		obj_class_lst = obj_class.split(/\s+/); //通过split空字符将cls转换成数组.
	x = 0;
	for(x in obj_class_lst) {
		if(obj_class_lst[x] == cls) { //循环数组, 判断是否包含cls
			return true;
		}
	}
	return false;
};

function newLoading(father) {
	var className = document.getElementById(father);

	var loadHtml = document.createElement("div");
	loadHtml.className = "loader loader-1";
	loadHtml.innerHTML = '<div class="loader-outter"></div>' +
		'<div class="loader-inner"></div>';

	className.appendChild(loadHtml);

}

function newLoadingHide(father) {
	var className = document.getElementById(father);
	className.removeChild(className.querySelector('.loader')) // 只刪除壞小孩 .bad

}

function bodyLoading() {

	var loadHtml = document.createElement("div");
	loadHtml.className = "loading";
	loadHtml.innerHTML = '<div class="loader loader-1" style="margin-top:200px;"><div class="loader-outter"></div>' +
		'<div class="loader-inner"></div></div>';

	document.getElementsByTagName("body")[0].appendChild(loadHtml);
}

function loadingHide() {

	var parent = document.getElementsByTagName("body")[0];
	parent.removeChild(parent.querySelector('.loading')) // 只刪除壞小孩 .bad
}
function loadings(){
		var loadHtml = document.createElement("div");
	loadHtml.className = "loading";
	loadHtml.innerHTML = '<div class="loader">'+
      '  <div class="loader-inner pacman">'+
         ' <div></div>'+
         ' <div></div>'+
         ' <div></div>'+
         ' <div></div>'+
          '<div></div>'+
       ' </div>'+
     ' </div>';

	document.getElementsByTagName("body")[0].appendChild(loadHtml);
}
function waitting() {

	bodyLoading();
	setTimeout(function() {
		loadingHide(); //新webview的载入完毕后关闭等待框
		document.getElementById("content").style.opacity = "1";
	}, 500)
}
//页面跳转
function pageGo(that) {
	var aniShow = "pop-in";
	var aniShowr = "slide-in-right";
	var id = that.getAttribute('href');
	var href = that.href;
	var type = that.getAttribute("open-type");
	//不使用父子模板方案的页面
	if(type == "common") {
		var webview_style = {
			popGesture: "close"
		};
		//侧滑菜单需动态控制一下zindex值；
		if(~id.indexOf('offcanvas-')) {
			webview_style.zindex = 9998;
			webview_style.popGesture = ~id.indexOf('offcanvas-with-right') ? "close" : "none";
		}
		//图标界面需要启动硬件加速
		if(~id.indexOf('icons.html')) {
			webview_style.hardwareAccelerated = true;
		}
		mui.openWindow({
			id: id,
			url: that.href,
			styles: webview_style,
			show: {
				aniShow: aniShow
			},
			waiting: {
				autoShow: false
			}

		});
	} else if(id && ~id.indexOf('.html')) {
		if(!mui.os.plus || (!~id.indexOf('popovers.html') && mui.os.ios)) {
			mui.openWindow({
				id: id,
				url: that.href,
				styles: {
					popGesture: 'close'
				},
				show: {
					aniShow: aniShow
				},
				waiting: {
					autoShow: false
				}
			});
		} else {
			//TODO  by chb 当初这么设计，是为了一个App中有多个模板，目前仅有一个模板的情况下，实际上无需这么复杂
			//使用父子模板方案打开的页面
			//获得共用模板组
			//var template = getTemplate('default');
			//判断是否显示右上角menu图标；
			mui.openWindow({
				id: id,
				url: that.href,
				//				styles: {
				//					popGesture: 'close'
				//				},
								show: {
									aniShow: aniShowr
								},
				waiting: {
					autoShow: false
				}
			});
		}
	}
}

//页面跳转2
function viewTo(href, data) {
	var aniShow = "pop-in";
	var aniShowz = "zoom-fade-out";
	var aniShowr = "slide-in-right";

	var id = href;

	var type = "";
	//不使用父子模板方案的页面
	if(type == "common") {
		var webview_style = {
			popGesture: "close"
		};
		//侧滑菜单需动态控制一下zindex值；
		if(~id.indexOf('offcanvas-')) {
			webview_style.zindex = 9998;
			webview_style.popGesture = ~id.indexOf('offcanvas-with-right') ? "close" : "none";
		}
		//图标界面需要启动硬件加速
		if(~id.indexOf('icons.html')) {
			webview_style.hardwareAccelerated = true;
		}
		mui.openWindow({
			id: id,
			url: href,
			styles: webview_style,
			show: {
				aniShow: aniShow
			},
			extras: data,
			waiting: {
				autoShow: false
			}

		});
	} else if(id && ~id.indexOf('.html')) {
		if(!mui.os.plus || (!~id.indexOf('popovers.html') && mui.os.ios)) {
			mui.openWindow({
				id: id,
				url: href,
				styles: {
					popGesture: 'close'
				},
				show: {
					aniShow: aniShow
				},
				extras: data,
				waiting: {
					autoShow: false
				}
			});
		} else {
			//TODO  by chb 当初这么设计，是为了一个App中有多个模板，目前仅有一个模板的情况下，实际上无需这么复杂
			//使用父子模板方案打开的页面
			//获得共用模板组
			//var template = getTemplate('default');
			//判断是否显示右上角menu图标；
//			mui.openWindow({
//				id: id,
//				url: href,
//				//				styles: {
//				//					popGesture: 'close'
//				//				},
//								show: {
//									aniShow: aniShowr
//								},
//				extras: data,
//				waiting: {
//					autoShow: false
//				}
//			});
 pageTo(href, data);
		}
	}
}
//页面跳转3
function viewToo(href, data) {
	var aniShow = "pop-in";
	var aniShowz = "zoom-fade-out";
	var aniShowr = "slide-in-right";

	var id = href;

	var type = "";
	//不使用父子模板方案的页面
	if(type == "common") {
		var webview_style = {
			popGesture: "close"
		};
		//侧滑菜单需动态控制一下zindex值；
		if(~id.indexOf('offcanvas-')) {
			webview_style.zindex = 9998;
			webview_style.popGesture = ~id.indexOf('offcanvas-with-right') ? "close" : "none";
		}
		//图标界面需要启动硬件加速
		if(~id.indexOf('icons.html')) {
			webview_style.hardwareAccelerated = true;
		}
		mui.openWindow({
			id: id,
			url: href,
			styles: webview_style,
			show: {
				aniShow: aniShowz
			},
			extras: data,
			waiting: {
				autoShow: false
			}

		});
	} else if(id && ~id.indexOf('.html')) {
		if(!mui.os.plus || (!~id.indexOf('popovers.html') && mui.os.ios)) {
			mui.openWindow({
				id: id,
				url: href,
				styles: {
					popGesture: 'close'
				},
				show: {
					aniShow: aniShowz
				},
				extras: data,
				waiting: {
					autoShow: false
				}
			});
		} else {
			//TODO  by chb 当初这么设计，是为了一个App中有多个模板，目前仅有一个模板的情况下，实际上无需这么复杂
			//使用父子模板方案打开的页面
			//获得共用模板组
			//var template = getTemplate('default');
			//判断是否显示右上角menu图标；
//			mui.openWindow({
//				id: id,
//				url: href,
//				//				styles: {
//				//					popGesture: 'close'
//				//				},
//								show: {
//									aniShow: aniShowr
//								},
//				extras: data,
//				waiting: {
//					autoShow: false
//				}
//			});
 pageTo(href, data);
		}
	}
}
//图片处理
function convertImgToBase64(url, callback, outputFormat) {
	var canvas = document.createElement('CANVAS'),
		ctx = canvas.getContext('2d'),
		img = new Image;
	img.crossOrigin = 'Anonymous';
	img.onload = function() {
		canvas.height = img.height;
		canvas.width = img.width;
		ctx.drawImage(img, 0, 0);
		var dataURL = canvas.toDataURL(outputFormat || 'image/png');
		callback.call(this, dataURL);
		canvas = null;
	};
	img.src = url;
}

function nobodyLoading() {

	var loadHtml = document.createElement("div");
	loadHtml.className = "noloading";
	loadHtml.innerHTML = '<div class="noloader noloader-1" style="margin-top:200px;"><div class="noloader-outter"></div>' +
		'<div class="noloader-inner"></div></div>';

	document.getElementsByTagName("body")[0].appendChild(loadHtml);
}

function noloadingHide() {
	var parent = document.getElementsByTagName("body")[0];
	parent.removeChild(parent.querySelector('.noloading')); // 只刪除壞小孩 .bad 
}

function setStatusbarRed() {
	// 设置系统状态栏背景色为红色
	plus.navigator.setStatusBarStyle("UIStatusBarStyleBlackOpaque");
	plus.navigator.setStatusBarBackground("#FFFFFF");
}

function setStatusbarMo() {
	if(mui.os.ios) {
		plus.navigator.setStatusBarStyle("UIStatusBarStyleDefault");
		plus.navigator.setStatusBarBackground("#ffffff");

	} else {
		plus.navigator.setStatusBarStyle("dark");
		plus.navigator.setStatusBarBackground("#ffffff");
	}

}

function dealPush(){
plus.push.addEventListener("click", function(msg) {
	var payload = (plus.os.name == 'iOS') ? msg.payload : JSON.parse(msg.payload);
	var datas = payload;
	if(datas.msg_type=="refond"){
            	
				
            }
			if(datas.msg_type=="message"){
            	viewTo( "pages/userCenter/message.html" );
				
            }
			if(datas.msg_type=="bill"){
            	viewTo( "pages/account.html" );
				
            }
	pushGetRun(payload);
}, false);
// 监听在线消息事件
plus.push.addEventListener("receive", function(msg) {
	if(msg.payload) {
		if(typeof(msg.payload) == "string") {
			plus.nativeUI.confirm("收到一条新消息，是否立即查看", function(e) {
				if(e.index == 0) {
					var h=plus.webview.getWebviewById( "pages/usercenter.html" );
							h.reload();
				}

			}, "温馨提示", ["知道了"]);
		} else {
			//alert( "消息："+msg.payload );
			var datas = msg.payload;
            //createLocalPushMsg(msg.content);
           
            	plus.nativeUI.confirm(datas.content, function(e) {
					if(e.index == 0) {}})
			if(datas.msg_type=="refond"){
            	var h=plus.webview.getWebviewById( "pages/usercenter.html" );
				h.reload();
				return;
            }
			if(datas.msg_type=="message"){
            	var h=plus.webview.getWebviewById( "pages/userCenter/message.html" );
				h.reload();
				return;
            }
			if(datas.msg_type=="bill"){
            	var h=plus.webview.getWebviewById( "pages/account.html" );
				h.reload();
				return;
            }
			pushGetRun()
			//							var id = msg.payload.id;
			//							var url = 'www/tpl/detail.html?id=' + id;
			//							plus.nativeUI.confirm("收到一条新消息，是否立即查看", function(e) {
			//								if(e.index == 0) {
			////									mui.openWindow({
			////										url: url,
			////										id: 'notice' + id
			////									});
			//
			//								}
			//							}, "新消息通知", ["查看", "忽略"]);
		}
	} else {
		//alert( "payload: undefined" );
	}
}, false);
	
}

function pushGetRun() {
	//				var id = payload.id;
	//				var url = 'www/tpl/detail.html?id=' + id;
	//				mui.openWindow({
	//					url: url,
	//					id: 'detail' + id
	//				});
	plus.push.clear();
	plus.runtime.setBadgeNumber(0);

}
function dotoast(tit,con,buntext){
	var loadHtml = document.createElement("div");
	loadHtml.className = "com-toast";
	loadHtml.innerHTML='<div class="com-tis">'+
				'<img class="com-ico" src="../img/ico2.png" />'+
				'<p class="com-tit">'+tit+'</p>'+
				'<p class="com-con" style="text-align:center">'+con+'</p>'+
				'<button class="com-bun">'+buntext+'</button>'+
			'</div>';
document.getElementsByTagName("body")[0].appendChild(loadHtml);		
}
function toastHide() {
	var parent = document.getElementsByTagName("body")[0];
	parent.removeChild(parent.querySelector('.com-toast')); // 只刪除壞小孩 .bad 
}